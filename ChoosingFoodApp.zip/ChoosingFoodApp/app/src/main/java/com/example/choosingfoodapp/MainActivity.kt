package com.example.choosingfoodapp

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.widget.Button
import android.widget.ImageView
import android.widget.TextView
import android.widget.Toast

class MainActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)
        var imgFood = findViewById<ImageView>(R.id.foodImageView)
        var textCharacter = findViewById<TextView>(R.id.txtFood)
        var btnRandom = findViewById<Button>(R.id.chooseButton)
        btnRandom.setOnClickListener{
            Toast.makeText(this,"Food choosing!",Toast.LENGTH_SHORT)
            var randomNumber = (1..5).random()
            when(randomNumber){
                1->{
                    imgFood.setImageResource(R.drawable.burger)
                    textCharacter.text="BURGER"
                }
                2->{
                    imgFood.setImageResource(R.drawable.pizza)
                    textCharacter.text="PIZZA"
            }
                3-> {
                    imgFood.setImageResource(R.drawable.kebab)
                    textCharacter.text = "KEBAB"
                }
                4-> {
                    imgFood.setImageResource(R.drawable.kofte)
                    textCharacter.text = "KOFTE"
                }
                5-> {
                    imgFood.setImageResource(R.drawable.lahmacun)
                    textCharacter.text = "LAHMACUN"
                }
        }
    }
}}